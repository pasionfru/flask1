
前端: HTML, CSS, JavaScript
后端: Python（Flask）
数据库:MySQL

